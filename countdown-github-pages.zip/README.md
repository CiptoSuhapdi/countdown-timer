# Countdown Timer

Website hitung mundur sederhana, responsif, dan berjalan otomatis setiap detik.

## Cara memasang di GitHub Pages
1. Masuk ke https://github.com dan buat repository baru, misalnya `countdown-timer`.
2. Pilih **Add file → Upload files**.
3. Unggah `index.html` dari folder ini, lalu klik **Commit changes**.
4. Buka **Settings → Pages** pada repository.
5. Pada **Build and deployment**, pilih **Deploy from a branch**.
6. Pilih branch `main` dan folder `/(root)`, lalu tekan **Save**.
7. Tunggu proses publikasi. Link website akan muncul di bagian GitHub Pages.

Pengunjung memilih tanggal dan jam tujuan lalu menekan **Mulai**. Zona waktu mengikuti perangkat yang membuka website.
